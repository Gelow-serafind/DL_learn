"""Saved source code for "Dive into Deep Learning" (https://d2l.ai).

Please import d2l by one of the following ways:

from d2l import mxnet as d2l  # Use MXNet as the backend
from d2l import torch as d2l  # Use PyTorch as the backend
from d2l import tensorflow as d2l  # Use TensorFlow as the backend
from d2l import jax as d2l  # Use Jax as the backend

"""

__version__ = "1.0.3"
